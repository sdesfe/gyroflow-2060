3K Pattern Remove v1 (DCTL for DaVinci Resolve)

INSTALL
Windows: right-click Install-Windows.bat > Run as administrator.
macOS:   double-click Install-macOS.command (if blocked: right-click > Open). Not tested yet.
Then restart DaVinci Resolve.

USE
Color page > Effects > drag DCTL onto your first node > DCTL list: 3K Pattern Remove > 3K Pattern Remove v1.
Then Resolve's Deflicker on the second node. Settings and screenshots:
https://github.com/sdesfe/gyroflow-2060/tree/main/3k-pattern-remove
